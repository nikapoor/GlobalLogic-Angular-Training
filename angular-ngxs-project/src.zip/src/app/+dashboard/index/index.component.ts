import { Component } from '@angular/core';

@Component({
  selector: 'ngxs-index',
  template: `
    <h3>Dashboard Home</h3>
  `
})
export class IndexComponent {}