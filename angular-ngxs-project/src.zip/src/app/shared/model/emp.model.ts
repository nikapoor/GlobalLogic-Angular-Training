export interface EMP {
    id: string,
    name: string,
    email: string,
    designation: string
}